
<?php $__env->startSection("content"); ?>
<table class="table table-hover mt-2 ms-2 me-s">
    <thead>
    <tr>
        <th scope="col">Index</th>
        <th scope="col">Ảnh</th>
        <th scope="col">Tên</th>
        <th scope="col">Giá</th>
        <th scope="col">Xuất xứ</th>
        <th scope="col">Action</th>
    </tr>
    </thead>
    <tbody>
        <?php
        $index=1; 
        ?>
        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="<?php echo e($item->id); ?>">
                <th scope="row"><?php echo e($index); ?></th>
                <td style="width: 200px;"><img style="width:50%;" src="<?php echo e(url('/')); ?>/public/images/products/<?php echo e($item->image); ?>" alt="<?php echo e($item->name); ?>"></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e(number_format($item->price)); ?></td>
                <td><?php echo e($item->origin); ?></td>
                <td>
                <a href="#" title="xóa"><i onclick="deleteProduct(<?php echo e($item->id); ?>)" class="fa-solid fa-trash text-danger ms-2"></i></a>
                </td>
            </tr>
            <?php
                $index++; 
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="pagination-center" style="display: flex;justify-content: center;"><?php echo e($product->links()); ?></div>
<script>
    function deleteProduct(id) {
            $.ajax({
                type: 'POST',
                url: '<?php echo e(route("delete_product")); ?>',
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    id:id
                },
                success: function(data) {
                    $('#'+id).remove()
                    new Notify ({
                        title: 'Thành công',
                        text: 'Xóa sản phẩm thành công',
                        status: 'success',
                        autoclose: true,
                        autotimeout: 1000
                    })
                }
            })
        }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.main.mainPage", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vape\resources\views/admin/product/list.blade.php ENDPATH**/ ?>