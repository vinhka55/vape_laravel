
<?php $__env->startSection("content"); ?>
    <div class="shipping-info">
        <h3>Thông tin nhận hàng</h3>
        <?php $__currentLoopData = $shipping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p>Họ tên: <?php echo e($item->name); ?></p>
            <p>Email: <?php echo e($item->email); ?></p>
            <p>Số điện thoại: <?php echo e($item->phone); ?></p>
            <p>Địa chỉ: <?php echo e($item->address); ?></p>
            <p>Phương thức thanh toán : <?php echo e($item->method); ?></p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="product-info">
        <h3>Thông tin sản phẩm</h3>
        <div class="info-cart">
            <table class="table product-checkout">
                <tbody>                
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="img" style="position: relative">
                                <img style="width: 25%;" class="product-checkout__img" src="<?php echo e(url('/')); ?>/public/images/products/<?php echo e($item->product_image); ?>" alt="<?php echo e($item->product_name); ?>">
                                <div class="qty-product-buy"><?php echo e($item->product_qty); ?> sản phẩm</div>
                            </td>
                            <td class="name"><?php echo e($item->product_name); ?></td>
                            <td class="price"><?php echo e($item->product_qty.' x '.number_format($item->product_price)); ?>đ</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="final-money">
                <span style="font-weight: 500">Tổng cộng</span>
                <span>VND <?php echo e(number_format($priceOrder)); ?>đ</span>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.main.mainPage", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vape\resources\views/admin/order/order_detail.blade.php ENDPATH**/ ?>