<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/public/assets/css/base.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/public/assets/css/main.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/public/assets/css/reponsive.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/public/assets/fonts/fontawesome-6.1.1/css/all.min.css">
    <title>Vape VN</title>
</head>
<body>
    <div class="wrapper-nav-small-screen" id="js-wrapper-navigation">
        <div class="nav-small-screen" id="js-nav-small-screen">
            <h3 class="heading-text text-center">Menu</h3>
            <ul class="nav-list">
                <li class="nav-item"><a class="nav-item__link" href="">home</a></li>
                <li class="nav-item"><a class="nav-item__link" href="">sale</a></li>
                <li class="nav-item"><a class="nav-item__link" href="">máy pod system</a></li>
                <li class="nav-item"><a class="nav-item__link" href="">tinh dầu satlnic</a></li>
                <li class="nav-item"><a class="nav-item__link" href="">phụ kiện pod</a></li>
                <li class="nav-item"><a class="nav-item__link" href="">pod relx juul</a></li>
                <li class="nav-item"><a class="nav-item__link" href="">dầu vape</a></li>
                <li class="nav-item"><a class="nav-item__link" href="">tin tức</a></li>
            </ul>
        </div>
    </div>
    <div class="header">
        <div class="grid content-top">
            <div class="content-top__logo">
                <a href="#"><img src="<?php echo e(url('/')); ?>/public/assets/img/logo/logo.webp" alt="logo" class="img-logo"></a>
            </div>
            <div class="content-top__middle">
                <div class="top-social">
                    <a href="#">
                        <i class="top-social__icon fa-brands fa-facebook"></i>
                    </a>
                    <a href="#">
                        <i class="top-social__icon fa-brands fa-instagram-square"></i>
                    </a>
                    <a href="#">
                        <i class="top-social__icon fa-brands fa-youtube"></i>
                    </a>
                </div>
                <div class="top-search">
                    <input type="text" class="input-search" placeholder="Tìm kiếm">
                    <button class="btn-top-search"><i class="fa-solid fa-magnifying-glass"></i></button>
                </div>
            </div>
            <div class="content-top__end">
                <div class="address">
                    <i class="fa-solid fa-phone"></i>
                    Hồ Chí Minh: 0833379934
                </div>
                <div class="table-nav" id="js-show-nav">
                    <i class="icon-md-nav fa-solid fa-bars"></i>
                </div>
                <div class="top-user">
                    <a href=""><i class="fa-solid fa-cart-arrow-down"></i></a>
                    <a href=""><i class="fa-solid fa-user"></i></a>
                </div>
            </div>
        </div>
    </div>

    <div class="navigation">
        <div class="grid">
            <nav class="top-menu">
                <ul class="top-menu-list">
                    <li class="top-menu-item">
                        <a href="" class="top-menu-item__link">Home</a>
                    </li>
                    <li class="top-menu-item">
                        <a href="" class="top-menu-item__link">Sale</a>
                    </li>
                    <li class="top-menu-item">
                        <a href="" class="top-menu-item__link">
                            Máy pod system
                            <i class="fa-solid fa-chevron-down"></i>
                        </a>
                        <ul class="sub-menu-list">
                            <li class="sub-menu"><a href="" class="sub-menu__link">Pod dùng 1 lần</a></li>
                        </ul>
                    </li>
                    <li class="top-menu-item">
                        <a href="" class="top-menu-item__link">
                            Tinh dầu satlnic
                            <i class="fa-solid fa-chevron-down"></i>
                        </a>
                        <ul class="sub-menu-list">
                            <li class="sub-menu"><a href="" class="sub-menu__link">nasty salt</a></li>
                            <li class="sub-menu"><a href="" class="sub-menu__link">icy fruity salt</a></li>
                            <li class="sub-menu"><a href="" class="sub-menu__link">summer salt</a></li>
                            <li class="sub-menu"><a href="" class="sub-menu__link">gold leaf salt</a></li>
                        </ul>
                    </li>
                    <li class="top-menu-item">
                        <a href="" class="top-menu-item__link">
                            Phụ kiện pod
                            <i class="fa-solid fa-chevron-down"></i>
                        </a>
                    </li>
                    <li class="top-menu-item">
                        <a href="" class="top-menu-item__link">
                            Pod relx | juul
                            <i class="fa-solid fa-chevron-down"></i>
                        </a>
                    </li>
                    <li class="top-menu-item">
                        <a href="" class="top-menu-item__link">
                            Dầu vape
                            <i class="fa-solid fa-chevron-down"></i>
                        </a>
                    </li>
                    <li class="top-menu-item">
                        <a href="" class="top-menu-item__link">Tin tức</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>

    <div class="slide">
        <div class="one-slide one-slide--active" style="background-image: url('<?php echo e(url('/')); ?>/public/assets/img/slide/index_slider_img_1.webp');">
            
        </div>
        <div class="one-slide" style="background-image: url('<?php echo e(url('/')); ?>/public/assets/img/slide/index_slider_img_3.webp');">

        </div>
        <div class="one-slide" style="background-image: url(<?php echo e(url('/')); ?>/public/assets/img/slide/index_slider_img_5.webp);">
            
        </div>
        <ul class="slide__list">
            <li class="slide__item slide__item--active">1</li>
            <li class="slide__item">2</li>
            <li class="slide__item">3</li>
        </ul>
    </div>

    <div class="category">
        <div class="grid">
            <div class="category__heading">
                <h3 class="category__heading-text common-heading__text">Danh mục sản phẩm</h3>
            </div>
            <div class="category__list" id="category-list">         
                    <div class="category__item category__item-sale" style="background-image: url('<?php echo e(url('/')); ?>/public/assets/img/category/sale.webp');">
                        <a href=""><h4 class="category__item-text">sale</h4></a>
                    </div>
                
                <div class="category__item category__item-pod" style="background-image: url('<?php echo e(url('/')); ?>/public/assets/img/category/iqos_iluma_prime_f07535657d9f4c729ace5fe8cbf6036a.webp');">
                    <a href=""><h4 class="category__item-text">iqos-lil</h4></a>
                </div>
                <div class="category__item category__item-saltnic" style="background-image: url('<?php echo e(url('/')); ?>/public/assets/img/category/relx_logo_vapepro_52a6288dbe1e4ec0a095811d5599d18a.webp');">
                    <a href=""><h4 class="category__item-text">pod relx | juul</h4></a>
                </div>
                <div class="category__item category__item-vape" style="background-image: url('<?php echo e(url('/')); ?>/public/assets/img/category/saltnic_vapepro_99908fffdf0e4aaf99e8c4058e648a58.webp');">
                    <a href=""><h4 class="category__item-text">Tinh dầu saltnic</h4></a>
                </div>
                <div class="category__item category__item-vape" style="background-image: url('<?php echo e(url('/')); ?>/public/assets/img/category/voopoo_vinci_pnp_vm4_0.webp');">
                    <a href=""><h4 class="category__item-text">phụ kiện pod</h4></a>
                </div>
                <div class="category__item category__item-vape" style="background-image: url('<?php echo e(url('/')); ?>/public/assets/img/category/smok_rpm4_main_1b5f45695dee4f6fb4a357615bd416e7.webp');">
                    <a href=""><h4 class="category__item-text">máy pod system</h4></a>
                </div>
                <div class="category__item category__item-vape" style="background-image: url('<?php echo e(url('/')); ?>/public/assets/img/category/1.webp');">
                    <a href=""><h4 class="category__item-text">dầu vape</h4></a>
                </div>
                <div class="btn-prev" onclick="prev()"><i class="icon-prev-slide fa-solid fa-angle-left"></i></div>
                <div class="btn-next" onclick="next()"><i class="icon-next-slide fa-solid fa-angle-right"></i></div>
            </div>
            <div class="category__footer">
                <div class="category__footer-item">
                    <div class="category__footer-item-img">
                        <i class="category__footer-item-icon fa-solid fa-car"></i>
                    </div>
                    <div class="category__footer-item-desc">
                        <a href="" class="category__footer-item-link">
                            <h3 class="title-desc">Giao hàng cod nhanh chóng</h3>
                            <p class="content-desc">Sản phẩm được giao từ 30 - 60 phút với các đơn hàng nội thành</p>
                        </a>
                    </div>
                </div>
                <div class="category__footer-item">
                    <div class="category__footer-item-img">
                        <i class="category__footer-item-icon fa-solid fa-dollar-sign"></i>
                    </div>
                    <div class="category__footer-item-desc">
                        <a href="" class="category__footer-item-link">
                            <h3 class="title-desc">Bảo hành</h3>
                            <p class="content-desc">Bảo hành  07 ngày nếu phát sinh lỗi từ nhà sản xuất</p>
                        </a>
                    </div>
                </div>
                <div class="category__footer-item">
                    <div class="category__footer-item-img">
                        <i class="category__footer-item-icon fa-solid fa-phone"></i>
                    </div>
                    <div class="category__footer-item-desc">
                        <a href="" class="category__footer-item-link">
                            <h3 class="title-desc">Hotline hỗ trợ</h3>
                            <p class="content-desc">HCM: 0833379934 - Bình Dương: 0398855263</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="product">
        <div class="grid">
            <div class="sale-off__heading">
                <h3 class="sale-off__heading-text common-heading__text">Sản phẩm khuyễn mãi</h3>
            </div>
            <div class="row">
                <div class="col-3 one-product">
                    <a href="">
                        <img src="<?php echo e(url('/')); ?>/public/assets/img/product/ice-grape.webp" alt="" class="product__img">
                        <h3 class="product__name text-color">Bộ pod system feelin 22w 1000mAh by nevoks</h3>
                        <p class="product__price text-color">160.000đ</p>
                    </a>
                    <div class="action-product">
                        <a href="">
                            <div class="action-product__icon">
                                <i class="fa-solid fa-cart-arrow-down"></i>
                            </div>
                        </a>
                        <a href="">
                            <div class="action-product__icon">
                                <i class="fa-solid fa-eye"></i>
                            </div>
                        </a>
                        <a href="">
                            <div class="action-product__icon">
                               <i class="fa-solid fa-magnifying-glass"></i>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-3 one-product">
                    <a href="">
                        <img src="<?php echo e(url('/')); ?>/public/assets/img/product/ice-grape.webp" alt="" class="product__img">
                        <h3 class="product__name text-color">Bộ pod system feelin 22w 1000mAh by nevoks</h3>
                        <p class="product__price text-color">160.000đ</p>
                    </a>
                    <div class="action-product">
                        <a href="">
                            <div class="action-product__icon">
                                <i class="fa-solid fa-cart-arrow-down"></i>
                            </div>
                        </a>
                        <a href="">
                            <div class="action-product__icon">
                                <i class="fa-solid fa-eye"></i>
                            </div>
                        </a>
                        <a href="">
                            <div class="action-product__icon">
                               <i class="fa-solid fa-magnifying-glass"></i>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-3 one-product">
                    <a href="">
                        <img src="<?php echo e(url('/')); ?>/public/assets/img/product/ice-grape.webp" alt="" class="product__img">
                        <h3 class="product__name text-color">Bộ pod system feelin 22w 1000mAh by nevoks</h3>
                        <p class="product__price text-color">160.000đ</p>
                    </a>
                    <div class="action-product">
                        <a href="">
                            <div class="action-product__icon">
                                <i class="fa-solid fa-cart-arrow-down"></i>
                            </div>
                        </a>
                        <a href="">
                            <div class="action-product__icon">
                                <i class="fa-solid fa-eye"></i>
                            </div>
                        </a>
                        <a href="">
                            <div class="action-product__icon">
                               <i class="fa-solid fa-magnifying-glass"></i>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-3 one-product">
                    <a href="">
                        <img src="<?php echo e(url('/')); ?>/public/assets/img/product/ice-grape.webp" alt="" class="product__img">
                        <h3 class="product__name text-color">Bộ pod system feelin 22w 1000mAh by nevoks</h3>
                        <p class="product__price text-color">160.000đ</p>
                    </a>
                    <div class="action-product">
                        <a href="">
                            <div class="action-product__icon">
                                <i class="fa-solid fa-cart-arrow-down"></i>
                            </div>
                        </a>
                        <a href="">
                            <div class="action-product__icon">
                                <i class="fa-solid fa-eye"></i>
                            </div>
                        </a>
                        <a href="">
                            <div class="action-product__icon">
                               <i class="fa-solid fa-magnifying-glass"></i>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-3 one-product">
                    <a href="">
                        <img src="<?php echo e(url('/')); ?>/public/assets/img/product/ice-grape.webp" alt="" class="product__img">
                        <h3 class="product__name text-color">Bộ pod system feelin 22w 1000mAh by nevoks</h3>
                        <p class="product__price text-color">160.000đ</p>
                    </a>
                    <div class="action-product">
                        <a href="">
                            <div class="action-product__icon">
                                <i class="fa-solid fa-cart-arrow-down"></i>
                            </div>
                        </a>
                        <a href="">
                            <div class="action-product__icon">
                                <i class="fa-solid fa-eye"></i>
                            </div>
                        </a>
                        <a href="">
                            <div class="action-product__icon">
                               <i class="fa-solid fa-magnifying-glass"></i>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-3 one-product">
                    <a href="">
                        <img src="<?php echo e(url('/')); ?>/public/assets/img/product/ice-grape.webp" alt="" class="product__img">
                        <h3 class="product__name text-color">Bộ pod system feelin 22w 1000mAh by nevoks</h3>
                        <p class="product__price text-color">160.000đ</p>
                    </a>
                    <div class="action-product">
                        <a href="">
                            <div class="action-product__icon">
                                <i class="fa-solid fa-cart-arrow-down"></i>
                            </div>
                        </a>
                        <a href="">
                            <div class="action-product__icon">
                                <i class="fa-solid fa-eye"></i>
                            </div>
                        </a>
                        <a href="">
                            <div class="action-product__icon">
                               <i class="fa-solid fa-magnifying-glass"></i>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="news">
        <div class="grid">
            <div class="news__heading">
                <h3 class="news__heading-text common-heading__text">Tin tức</h3>
            </div>
            <div class="row">
                <div class="col-4 md-news">
                    <a href="">
                        <div class="box-img" style="height: 260px;">
                            <img class="news__img" src="<?php echo e(url('/')); ?>/public/assets/img/news/steamwork.webp" alt="">
                        </div>
                        <h3 class="news__title">STEAMWORK ỔI - LỰA CHỌN HOÀN HẢO DÀNH CHO DÂN MÊ KHÓI</h3>
                    </a>
                    <p class="news__desc">
                        Một mùa nóng bức thì các bạn giải nhiệt cho bản thân như thế nào? Nay VapePro mang đến cho các bạn một dòng tinh dầu thuốc lá điện tử...
                    </p>
                    <a href="" class="news__detail">
                        <i class="fa-solid fa-angle-right"></i>
                        Xem chi tiết
                    </a>
                </div>
                <div class="col-4 md-news">
                    <a href="">
                        <div class="box-img" style="height: 260px;">
                            <img class="news__img" src="<?php echo e(url('/')); ?>/public/assets/img/news/hannya-nano.webp" alt="">
                        </div>
                        <h3 class="news__title">LẠC LỐI TRONG KHÔNG GIAN MA MỊ CÙNG POD BÁCH QUỶ HANNYA NANO</h3>
                    </a>
                    <p class="news__desc">
                        Pod bách quỷ mới nhất đến từ nhà Vapelusion đang nổi như cồn sau Vape quỷ Hannya 230w. Với thiết kế cực kì đẹp mắt và cao cấp chắc chắn...
                    </p>
                    <a href="" class="news__detail">
                        <i class="fa-solid fa-angle-right"></i>
                        Xem chi tiết
                    </a>
                </div>
                <div class="col-4 md-news">
                    <a href="">
                        <div class="box-img" style="height: 260px;">
                            <img class="news__img" src="<?php echo e(url('/')); ?>/public/assets/img/news/vape-vinci.webp" alt="">
                        </div>
                        <h3 class="news__title">CHƠI KHÓI CÓ NÊN MUA VAPE VINCI X HAY KHÔNG?</h3>
                    </a>
                    <p class="news__desc">
                        Mua Vape Vinci X anh em sẽ được sở hữu dòng thuốc lá điện tử nhỏ gọn, sử dụng Pod System thay tank hay đầu đốt. Điểm nhấn ấn tượng...
                    </p>
                    <a href="" class="news__detail">
                        <i class="fa-solid fa-angle-right"></i>
                        Xem chi tiết
                    </a>
                </div>
            </div>
        </div>
        <div class="see-more-news">
            <a href="" class="see-more-news--link">
                <i class="fa-solid fa-chevron-down"></i>
                Xem thêm
            </a>
        </div>   
    </div>

    <div class="footer">
        <div class="grid">
            <div class="row mobile-footer">
                <div class="footer__introduce md-footer">
                    <h2 class="title">Giới thiệu VAPEPRO</h2>
                    <p class="desc">VapePro chuyên cung cấp các sản phẩm iQOS Pod System Tinh dầu Salt Nic, Thân máy, đầu đốt, Phụ kiện Pod System chính hãng với sự phục vụ chuyên nghiệp và uy tín. VapePro mở cửa và phục vụ khách hàng từ 9:00 - 21:00 hàng ngày, kể cả Chủ nhật.
                    </p>
                </div>
                <div class="footer__address md-footer">
                    <h2 class="title">Địa chỉ VAPEPRO</h2>
                    <p class="desc">
                        <p class="detail-address">
                            <span class="location">hồ chí minh</span>
                            # 343 Phan Đình Phùng, P15, Q Bình Thạnh 090 464 8689
                        </p>
                        <p class="detail-address">
                            <span class="location">BÌNH DƯƠNG</span>
                            # 117, Phường Đông Hòa, Thị xã Dĩ An, Tỉnh Bình Dương 0398855263
                        </p>                      
                    </p>
                </div>
                <div class="footer__support md-footer">
                    <h2 class="title">Chăm sóc khách hàng</h2>
                    <ul>
                        <li class="footer__support-item"><a class="footer__support-link" href="">Sản phẩm khuyễn mãi</a> </li>
                        <li class="footer__support-item"><a class="footer__support-link" href="">Sản phẩm nổi bật</a> </li>
                        <li class="footer__support-item"><a class="footer__support-link" href="">Tất cả sản phẩm</a> </li>
                        <li class="footer__support-item"><a class="footer__support-link" href="">Ưu đãi thành viên</a> </li>
                        <li class="footer__support-item"><a class="footer__support-link" href="">Khuyễn mãi</a></li>
                        <li class="footer__support-item"><a class="footer__support-link" href="">Chính sách vận chuyển</a> </li>
                        <li class="footer__support-item"><a class="footer__support-link" href="">Chính sách bảo hành</a></li>
                    </ul>
                </div>
                <div class="footer__connect">
                    <h2 class="title">Kết nối với chúng tôi</h2>
                    <ul class="footer__connect-list">
                        <li class="footer__connect-item">
                            <a href="#">
                                <i class="top-social__icon fa-brands fa-facebook"></i>
                            </a>
                        </li>
                        <li class="footer__connect-item">
                            <a href="#">
                                <i class="top-social__icon fa-brands fa-instagram-square"></i>
                            </a>
                        </li>
                        <li class="footer__connect-item">
                            <a href="#">
                                <i class="top-social__icon fa-brands fa-youtube"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>
<script src="<?php echo e(url('/')); ?>/public/assets/js/main.js"></script>
<script>
    var categoryList=document.getElementById('category-list')
    var categoryItem=document.getElementsByClassName('category__item')
    function next(){
        categoryList.append(categoryItem[0])
    }
    function prev(){
        categoryList.prepend(categoryItem[categoryItem.length-1])
    }
    var btnShowNav=document.getElementById('js-show-nav')
    var jsNavSmallScreen=document.getElementById('js-nav-small-screen')
    var wrapperNavigation=document.getElementById('js-wrapper-navigation')
    btnShowNav.onclick=function(){
        wrapperNavigation.style.display="block"
        wrapperNavigation.classList.add("animation-nav-small-screen")
    }
    // When the user clicks anywhere outside of the nav mobile or tablet, close it
    window.onclick = function(event) {
        if (event.target == wrapperNavigation) {
            wrapperNavigation.classList.remove("animation-nav-small-screen")
        }
    }
</script>
</html><?php /**PATH C:\xampp\htdocs\vape\resources\views/mainPage.blade.php ENDPATH**/ ?>