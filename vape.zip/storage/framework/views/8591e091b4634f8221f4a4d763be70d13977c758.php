

<?php $__env->startSection("title","Vape VN - Collections"); ?>
<?php $__env->startSection("content"); ?>

    <div class="breabrum">
        <div class="grid content-breabrum">
            <a href="<?php echo e(route('home')); ?>" class="link-home">Trang chủ</a>
            <span style="color: white;margin:0 5px;font-size:1.5rem;">/</span>
            <a href="<?php echo e(route('index_collections')); ?>" class="text-collections">Danh mục</a>
            <span style="color: white;margin:0 5px;font-size:1.5rem;">/</span>
            <span class="text-collections"><?php echo e($thisSubCategoryProduct->name); ?></span>
        </div>
    </div>

    <div class="grid collections-page">
        <div class="row">
            <div class="col-2 md-cateogry">
                <div class="category">
                    <h3>Danh mục</h3>
                    <ul class="list-category">
                        <li class="item-category"><a href="<?php echo e(route('home')); ?>" class="link-category">HOME</a></li>
                        <?php $__currentLoopData = $categoryProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="item-category"><a href="<?php echo e(route('show_product_with_category',$item->slug)); ?>" class="link-category"><?php echo e($item->name); ?></a></li>                   
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li class="item-category"><a href="#" class="link-category">TIN TỨC</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-10 md-product" style="padding-left: 24px;">
                <div class="product">
                    <h3 class="name-category" style="text-transform: uppercase;font-size:2rem"><?php echo e($thisSubCategoryProduct->name); ?></h3>
                    <div class="row">
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-2-5 one-product scale-product">
                                <a href="<?php echo e(route('detail_product',$item->slug)); ?>">
                                    <img src="<?php echo e(url('/')); ?>/public/images/products/<?php echo e($item->image); ?>" alt="<?php echo e($item->name); ?>" class="product__img">
                                    <h3 class="product__name text-color"><?php echo e($item->name); ?></h3>
                                    <p class="product__price text-color"><?php echo e($item->price); ?>đ</p>
                                </a>
                                <div class="action-product">                       
                                    <div class="action-product__icon">
                                        
                                        <button class="js-get-data" data-id=<?php echo e($item->id); ?> data-image=<?php echo e($item->image); ?> data-name=<?php echo e($item->name); ?> data-price=<?php echo e($item->price); ?> data-bs-toggle="modal" data-bs-target="#modalCart" style="background-color: black;border:none;">
                                            <i class="fa-solid fa-cart-arrow-down" style="color: white"></i>
                                        </button>
                                    </div>                                         
                                    <a href="<?php echo e(route('detail_product',$item->slug)); ?>">
                                        <div class="action-product__icon">
                                            <i class="fa-solid fa-eye"></i>
                                        </div>
                                    </a>
                                    <a href="">
                                        <div class="action-product__icon">
                                        <i class="fa-solid fa-magnifying-glass"></i>
                                        </div>
                                    </a>
                                </div>
                            </div>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                       
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("user.main.mainPage", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vape\resources\views/user/products/product_with_category.blade.php ENDPATH**/ ?>