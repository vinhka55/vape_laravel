
<?php $__env->startSection("content"); ?>
<table class="table table-hover mt-2 ms-2 me-s">
    <thead>
    <tr>
        <th scope="col">Index</th>
        <th scope="col">Mã đơn</th>
        <th scope="col">Thời gian</th>
        <th scope="col">Tiền</th>
        <th scope="col">Giảm giá</th>
        <th scope="col">Trạng thái</th>
        <th scope="col">Id khách</th>
        <th scope="col">Chi tiết</th>
    </thead>
    <tbody>
        <?php
        $index=1; 
        ?>
        <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th scope="row"><?php echo e($index); ?></th>
            <td><?php echo e($item->order_code); ?></td>
            <td><?php echo e($item->time); ?></td>
            <td><?php echo e(number_format($item->money)); ?> VND</td>
            <td><?php echo e($item->discount); ?> VND</td>
            <td><?php echo e($item->status); ?></td>
            <td><?php echo e($item->customer_id); ?></td>        
            <td><a href="<?php echo e(route('order_detail',$item->id)); ?>">Chi tiết</a></td>        
            </tr>
            <?php
                $index++; 
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="pagination-center" style="display: flex;justify-content: center;"><?php echo e($all->links()); ?></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.main.mainPage", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vape\resources\views/admin/order/list.blade.php ENDPATH**/ ?>