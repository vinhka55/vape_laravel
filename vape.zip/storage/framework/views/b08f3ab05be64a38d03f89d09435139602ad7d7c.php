
<?php $__env->startSection("title","Vape VN - Collections"); ?>
<?php $__env->startSection("content"); ?>
    <div class="breabrum">
        <div class="grid content-breabrum">
            <a href="<?php echo e(route('home')); ?>" class="link-home">Trang chủ</a>
            <span style="color: white;margin-right:5px;font-size:1.5rem;">/</span>
            <span class="text-collections">Collections</span>
        </div>
    </div>
    <div class="grid all-category">
        <h3 class="title">Danh mục</h3>
        <div class="row">
            <?php $__currentLoopData = $categoryProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-3 mt-2 one-category md-33 ms-100">
                <a href="<?php echo e(route('show_product_with_category',$item->slug)); ?>">
                    <img src="<?php echo e(url('/')); ?>/public/assets/img/product/ice-grape.webp" alt="" class="product__img">
                    <h3 class="category__name text-color text-center"><?php echo e($item->name); ?></h3>
                    <p class="product__count text-color text-center"><?php echo e($item->product_count); ?> sản phẩm</p>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $subCategoryProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-3 mt-2 one-category">
                <a href="<?php echo e(route('show_product_with_category',$item->slug)); ?>">
                    <img src="<?php echo e(url('/')); ?>/public/assets/img/product/ice-grape.webp" alt="" class="product__img">
                    <h3 class="category__name text-color text-center"><?php echo e($item->name); ?></h3>
                    <p class="product__count text-color text-center"><?php echo e($item->product_count); ?> sản phẩm</p>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("user.main.mainPage", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vape\resources\views/user/collections/collection.blade.php ENDPATH**/ ?>