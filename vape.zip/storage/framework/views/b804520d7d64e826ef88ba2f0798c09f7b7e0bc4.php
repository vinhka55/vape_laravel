
<?php $__env->startSection("title","Vape VN - Collections"); ?>
<?php $__env->startSection("content"); ?>
    <div class="breabrum">
        <div class="grid content-breabrum">
            <a href="<?php echo e(route('home')); ?>" class="link-home">Trang chủ</a>
            <span style="color: white;margin-right:5px;font-size:1.5rem;">/</span>
            <span class="text-collections">Tài khoản</span>
            <span style="color: white;margin-right:5px;font-size:1.5rem;">/</span>
            <span class="text-collections">Lịch sử đơn hàng</span>
        </div>
    </div>
    <div class="grid">
        <h2>TÀI KHOẢN</h2>
        <h4>ĐƠN ĐẶT HÀNG TRƯỚC ĐÓ</h4>
        <table class="table table-hover mt-2 ms-2 me-s">
            <thead>
            <tr>
                <th scope="col">Index</th>
                <th scope="col">Mã đơn</th>
                <th scope="col">Thời gian</th>
                <th scope="col">Tiền</th>
                <th scope="col">Giảm giá</th>
                <th scope="col">Trạng thái</th>

            </thead>
            <tbody>
                <?php
                $index=1; 
                ?>
                <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th scope="row"><?php echo e($index); ?></th>
                    <td><?php echo e($item->order_code); ?></td>
                    <td><?php echo e($item->time); ?></td>
                    <td><?php echo e(number_format($item->money)); ?> VND</td>
                    <td><?php echo e($item->discount); ?> VND</td>
                    <td><?php echo e($item->status); ?></td>
      
                    </tr>
                    <?php
                        $index++; 
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <h4>THÔNG TIN TÀI KHOẢN</h4>
        <?php
            echo '<p style="font-size:1.5rem;"> Họ và tên: '.Auth::user()->name.'</p>';
            echo '<p style="font-size:1.5rem;"> Email: '.Auth::user()->email.'</p>';
        ?>
        <a href="<?php echo e(route('logout')); ?>" style="background-color: black;padding:8px 16px;color:white">Đăng xuất</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("user.main.mainPage", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vape\resources\views/user/account/profile.blade.php ENDPATH**/ ?>